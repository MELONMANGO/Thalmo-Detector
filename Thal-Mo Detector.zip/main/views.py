from django.shortcuts import render
from django.http import HttpResponse,StreamingHttpResponse
from django.views.decorators import gzip
from django.core.mail import EmailMessage
from .models import Image
from .talmo.talmo import discriminate
from .DS_thalmo.thalmo import *
from .forms import ImageForm
import shutil
import cv2
import threading
import time

def Main_O(request):
	return render(request=request,
				  template_name='main/Main_O.html',)

def Main_X(request):
	return render(request=request,
				  template_name='main/Main_X.html',)

def nrt(request):
	return render(request=request,
				  template_name='main/nrt.html',)

def homepage(request, talmodata, title, percentage):
	return render(request=request,
				  template_name='main/home.html',
				  context={"talmodata": talmodata, "title": title, "percentage":percentage})

def nhomepage(request, talmodata, title, percentage):
	return render(request=request,
				  template_name='main/nhome.html',
				  context={"talmodata": talmodata, "title": title, "percentage":percentage})

def cheers(request):
	return render(request=request,
				  template_name='main/cheers.html',)

def talmo_percent(talmodata):
	if talmodata<=10:
		return "안전하지만, 탈모 가능성 존재"
	if talmodata>=70:
		return "고위험군!!! 탈모 유형을 즉시 검사하세요"
	else:
		return "예비 탈모 위험합니다."

def ai(request):
	"""Process images uploaded by users"""
	if request.method == 'POST':
		form = ImageForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			img = form.instance
			talmodata = discriminate("C:/Users/USER/mysite/media")
			img.image.delete()
			percentage = talmo_percent(talmodata)
			return homepage(request, talmodata, "AI로 판단한 탈모 진행도", percentage)
	else:
		form = ImageForm()
	return render(request, 'main/ai_img_import.html', {'form': form})

def nai(request):
	"""Process images uploaded by users"""
	if request.method == 'POST':
		form = ImageForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			img = form.instance
			talmodata = discriminate("C:/Users/USER/mysite/media")
			img.image.delete()
			percentage = talmo_percent(talmodata)
			return nhomepage(request, talmodata, "AI로 판단한 탈모 진행도", percentage)
	else:
		form = ImageForm()
	return render(request, 'main/ai_img_import.html', {'form': form})

def Result(request, talmodata, title, imgsrc):
	return render(request=request,
				  template_name='main/Result.html',
				  context={"talmodata": talmodata, "title": title, "imgsrc": imgsrc})

def camera_ai(request):
	talmodata = discriminate("C:/Users/USER/mysite/media")
	percentage = talmo_percent(talmodata)
	return homepage(request, talmodata, "AI로 판단한 탈모 진행도", percentage)

def camera_opencv(request):
	talmodata = image_result("C:/Users/USER/mysite/media/main/image.png")
	imgsrc = get_imgsrc(talmodata)
	return Result(request, talmodata, "탈모유형", imgsrc)

def ncamera_opencv(request):
	talmodata = nimage_result("C:/Users/USER/mysite/media/main/image.png")
	imgsrc = get_imgsrc(talmodata)
	return Result(request, talmodata, "탈모유형", imgsrc)

def opencv(request):
	if request.method == 'POST':
		form = ImageForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			img = form.instance
			talmodata = image_result("C:/Users/USER/mysite/media/"+str(img.image.name))
			img.image.delete()
			imgsrc = get_imgsrc(talmodata)
			return Result(request, talmodata, "탈모유형", imgsrc)
	else:
		form = ImageForm()
	return render(request, 'main/opencv_img_import.html', {'form': form})

def nopencv(request):
	if request.method == 'POST':
		form = ImageForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			img = form.instance
			talmodata = nimage_result("C:/Users/USER/mysite/media/"+str(img.image.name))
			img.image.delete()
			imgsrc = get_imgsrc(talmodata)
			return Result(request, talmodata, "탈모유형", imgsrc)
	else:
		form = ImageForm()
	return render(request, 'main/opencv_img_import.html', {'form': form})

def get_imgsrc(talmodata):
	img_source=['https://i.ibb.co/d5ptv2R/end.png','https://i.ibb.co/ZTg9VQ5/m1.png','https://i.ibb.co/Lh1H04W/m2.png',
				'https://i.ibb.co/N7wmhp6/m3.png','https://i.ibb.co/N15Xp4J/m4.png','https://i.ibb.co/s6MB0MG/mo1.png',
				'https://i.ibb.co/Y3B0FKV/mo2.png','https://i.ibb.co/Cm5z25g/mo3.png','https://i.ibb.co/qRLt3g5/mo4.png',
				'https://i.ibb.co/mFs53ky/o1.png','https://i.ibb.co/C8x9vfj/o2.png','https://i.ibb.co/kmVsd4F/o3.png',
				'https://i.ibb.co/gSt0Z1R/o4.png','https://i.ibb.co/mbk2KjN/u1.png','https://i.ibb.co/sRG8TsP/u2.png',
				'https://i.ibb.co/DK7CsXv/u3.png','https://i.ibb.co/N2wSz3Y/u4.png']
	if talmodata=='end':
  		return img_source[0]
	if talmodata[0]=='o':
  		return img_source[8+int(talmodata[1])]
	if talmodata[0]=='u':
  		return img_source[12+int(talmodata[1])]
	if talmodata[0]=='m':
  		if talmodata[1]=='o':
  			return img_source[4+int(talmodata[2])]
  		return img_source[0+int(talmodata[1])]

@gzip.gzip_page
def Home_ai(request):
	try:
		cam = VideoCamera()
		return StreamingHttpResponse(gen_ai(cam), content_type="multipart/x-mixed-replace;boundary=frame")
	except:
		pass
	return

def Home_opencv(request):
	try:
		cam = VideoCamera()
		return StreamingHttpResponse(gen_opencv(cam), content_type="multipart/x-mixed-replace;boundary=frame")
	except:
		pass
	return

#to capture video class
class VideoCamera(object):
	def __init__(self):
		self.video = cv2.VideoCapture(0)
		(self.grabbed, self.frame) = self.video.read()
		threading.Thread(target=self.update, args=()).start()

	def __del(self):
		self.video.release()

	def get_frame_nob(self):
		image = self.frame
		_, jpeg = cv2.imencode('.jpg', image)
		return jpeg.tobytes()

	def get_frame(self, time):
		image = self.frame
		image = cv2.putText(image, str(time), (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
		cv2.circle(image, (248, 300), 5, (255, 0, 0), 2)
		cv2.circle(image, (372, 300), 5, (255, 0, 0), 2)
		cv2.circle(image, (310, 225), 215, (255, 0, 0), 2)
		cv2.line(image, (310, 310), (310, 370), (255, 0, 0), 2)
		cv2.line(image, (285, 392), (335, 392), (255, 0, 0), 2)
		_, jpeg = cv2.imencode('.jpg', image)
		return jpeg.tobytes()

	def update(self):
		while True:
			(self.grabbed, self.frame) = self.video.read()

def gen_ai(camera):
   cur_time = time.time()
   while time.time()-cur_time < 5:
      ctime = int(5 + cur_time - time.time())
      frame = camera.get_frame(ctime)
      yield (b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')
   success, img = camera.video.read()
   cv2.imwrite('C:/Users/USER/mysite/media/main/image.png', img)
   draw(img)
   cv2.imwrite('C:/Users/USER/mysite/hairline/main/hairimage.png', img)
   camera.video.release()
   HttpResponse.close()


def gen_opencv(camera):
	cur_time = time.time()
	while time.time()-cur_time < 10:
		ctime = int(10 + cur_time - time.time())
		frame = camera.get_frame(ctime)
		yield (b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')
	success, img = camera.video.read()
	cv2.imwrite('C:/Users/USER/mysite/media/main/image.png', img)
	draw(img)
	cv2.imwrite('C:/Users/USER/mysite/hairline/main/hairimage.png', img)
	camera.video.release()
	HttpResponse.close()