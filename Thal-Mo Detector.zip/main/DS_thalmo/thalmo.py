import cv2
import time
import numpy as np

def hairlines(img):
    output = [50 for x in range(57)]
    for i in range(57):
        switch = 1
        for j in range(160-(abs(29-i)**2)*30//841, -1, -3):
            if i == 0 or j < output[i-1] + 20:
                a = img.item(50 + j, 180 + 5 * i, 0)
                b = img.item(50 + j, 180 + 5 * i, 1)
                c = img.item(50 + j, 180 + 5 * i, 2)
                if a < 80 and b < 80 and c < 80 and switch:
                    output[i] = 50 + j
                    switch = 0
    for c in range(57):
        cv2.circle(img, (180 + 5 * c, output[c]), 1, (0, 255, 0), 1)
    return output

def draw(img):
    output = hairlines(img)
    for i in range(57):
        cv2.circle(img, (180 + 5 * i, output[i]), 2, (0,255,0), -1)

def std(output, datum):
    value = 0
    for i in range(57):
        if output[i]-int(datum[i]) < 0: #기준이 더 위에 있을 때
            value += 2 * (output[i]-int(datum[i]))**2
        value += (output[i] - int(datum[i]))**2
    return value/57

def simmilarity(output,f):
    stddata = [200]*57
    type = 'normal'
    minValue = std(output, stddata)
    for b in range(17):
        stddata = f.readline().split(', ')
        if not (5 <= b <= 12 or not b):
            continue
        if std(output, stddata[1:]) < minValue:
            type = stddata[0]
            minValue = std(output, stddata[1:])
    return type

def nsimmilarity(output,f):
    stddata = [200]*57
    type = 'normal'
    minValue = std(output, stddata)
    for b in range(17):
        stddata = f.readline().split(', ') 
        if 5 <= b <= 12:
            continue
        if std(output, stddata[1:]) < minValue:
            type = stddata[0]
            minValue = std(output, stddata[1:])
    return type

def image_result(name):
    f = open("C:/Users/USER/mysite/main/DS_thalmo/standard_data.txt", 'r')
    img = cv2.imread(name)
    hair_data = hairlines(img)
    return simmilarity(hair_data,f)

def nimage_result(name):
    f = open("C:/Users/USER/mysite/main/DS_thalmo/standard_data.txt", 'r')
    img = cv2.imread(name)
    hair_data = hairlines(img)
    return nsimmilarity(hair_data,f)