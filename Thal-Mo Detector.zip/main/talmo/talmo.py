import torch
import torch.nn as nn
import torch.utils.data as udata
import torchvision.datasets as dataset
import torchvision.transforms as transforms
import torch.optim as optim
import matplotlib.pyplot as plt
import torchvision.utils as vutils
import numpy as np
import math

device = torch.device("cpu")

class Discriminator(nn.Module):
    def __init__(self, ngpu):
        super(Discriminator, self).__init__()
        self.ngpu = 0
        self.main = nn.Sequential(
            nn.Conv2d(3, 64, 4, 2, 1, bias=False), # [3, 64, 64] -> [64, 32, 32]
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2),
            nn.Conv2d(64, 128, 4, 2, 1, bias=False), # [64, 32, 32] -> [128, 16, 16]
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2),
            nn.Conv2d(128, 256, 4, 2, 1, bias=False), # [128, 16, 16] -> [256, 8, 8]
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2),
            nn.Conv2d(256, 512, 4, 2, 1, bias=False), # [256, 8, 8] -> [512, 4, 4]
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2),
            nn.Conv2d(512, 1, 4, 1, 0, bias=False), # [512, 4, 4] -> [1, 1, 1]
            nn.Sigmoid()
        )
    def forward(self, input):
        return self.main(input)

def discriminate(root, index=0):
    data = dataset.ImageFolder(root = root, transform = transforms.Compose([
        transforms.Resize(64), # resizing into [64, 64<=] or [64<=, 64]
        transforms.CenterCrop(64), # having a square image of [64, 64]
        transforms.ToTensor(), # converting into tensor in order to use it
        transforms.Normalize((0.5, 0.5, 0.5),(0.5, 0.5, 0.5)) # 3D's mean & standard derivation = 0.5
        ]))
    dataloader = iter(udata.DataLoader(data, batch_size=1, num_workers=0))
    for i in range(index):
        next(dataloader)
    data = next(dataloader)[0].to(device)
    netD = Discriminator(0).to(device)
    netD.load_state_dict(torch.load("C:/Users/USER/mysite/main/talmo/netD.pt"))
    
    y = netD(data.detach()).view(-1)[0]
    if y<0.9:
        y = math.log(y/(1-y))
        if y<0: y = -y
    else:
        y = math.exp(y)
        y = math.log(y)
        y = 100*y
    return y
