import torch
import torch.nn as nn
import torch.utils.data as udata
import torchvision.datasets as dataset
import torchvision.transforms as transforms
import torch.optim as optim
import matplotlib.pyplot as plt
import torchvision.utils as vutils
import numpy as np
import math

device = torch.device("cpu")

class Discriminator(nn.Module):
    def __init__(self, ngpu):
        super(Discriminator, self).__init__()
        self.ngpu = 0
        self.main = nn.Sequential(
            nn.Conv2d(3, 64, 4, 2, 1, bias=False), # [3, 64, 64] -> [64, 32, 32]
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2),
            nn.Conv2d(64, 128, 4, 2, 1, bias=False), # [64, 32, 32] -> [128, 16, 16]
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2),
            nn.Conv2d(128, 256, 4, 2, 1, bias=False), # [128, 16, 16] -> [256, 8, 8]
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2),
            nn.Conv2d(256, 512, 4, 2, 1, bias=False), # [256, 8, 8] -> [512, 4, 4]
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2),
            nn.Conv2d(512, 1, 4, 1, 0, bias=False), # [512, 4, 4] -> [1, 1, 1]
            nn.Sigmoid()
        )
    def forward(self, input):
        return self.main(input)

def weight_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.normal_(m.weight.data, 0.0, 0.02)

def load():
    netD = Discriminator(0).to(device)
    netD.apply(weight_init)
    netD.zero_grad() # initiation for zero

    # Load parameters
    netD.load_state_dict(torch.load("netD.pt"))
    netD.eval()

    print(netD)

    show_result()

def save(netD, D_Losses = []):
    torch.save(netD.state_dict(), "netD.pt")
    torch.save(D_Losses, "DLoss.pt")

def learn(saveData = False):
    batch = 50
    REAL = 1.
    FAKE = -1.
    num_epochs = 10

    talmodata = dataset.ImageFolder(root = "datatalmo", transform = transforms.Compose([
        transforms.Resize(64), # resizing into [64, 64<=] or [64<=, 64]
        transforms.CenterCrop(64), # having a square image of [64, 64]
        transforms.ToTensor(), # converting into tensor in order to use it
        transforms.Normalize((0.5, 0.5, 0.5),(0.5, 0.5, 0.5)) # 3D's mean & standard derivation = 0.5
        ]))
    notalmodata = dataset.ImageFolder(root = "datanotalmo", transform = transforms.Compose([
        transforms.Resize(64), # resizing into [64, 64<=] or [64<=, 64]
        transforms.CenterCrop(64), # having a square image of [64, 64]
        transforms.ToTensor(), # converting into tensor in order to use it
        transforms.Normalize((0.5, 0.5, 0.5),(0.5, 0.5, 0.5)) # 3D's mean & standard derivation = 0.5
        ]))

    talmodataloader = udata.DataLoader(talmodata, batch_size=batch, shuffle=True, num_workers=0)
    notalmodataloader = udata.DataLoader(notalmodata, batch_size=batch, shuffle=True, num_workers=0)

    netD = Discriminator(0).to(device)
    netD.apply(weight_init)
    netD.zero_grad() # initiation for zero

    LossFunc = nn.BCELoss() # Binary CrossEntropy
    optimizerD = optim.Adam(netD.parameters(), lr=0.0001, betas=(0.5, 0.999))

    D_Losses = []
    iters = 0
    for epoch in range(1, num_epochs+1):
        for i in range(1, min(len(talmodataloader), len(notalmodataloader))+1):
            i += 1
            td = iter(talmodataloader)
            ntd = iter(notalmodataloader)
            talmodata = next(td)
            notalmodata = next(ntd)
            #######Discriminator########
            netD.zero_grad() # initialization / resetting
            ##### D(x) ######
            real = talmodata[0].to(device)
            batch_size = real.size(0)
            label = torch.full((batch_size,), REAL, dtype=torch.float, device=device) # want to be real, size: [batch_size]
            output = netD(real.detach()).view(-1) # size: [batch_size, 1, 1, 1] -> [batch_size] by .view(-1)
            # .detach(): should not change the given data!
            errD_real = LossFunc(output, label) # Binary CrossEntropy
            errD_real.backward(retain_graph = True) # Gradients
            D_x = output.mean().item() # D(x) in float(to bring to CPU)
            ### 1-D(G(z)) ###
            fake = notalmodata[0].to(device)
            label.fill_(FAKE) # want to be fake, size: [batch_size](unchanged)
            output = netD(fake.detach()).view(-1) # size: [batch_size, 1, 1, 1] -> [batch_size] by .view(-1) /
            # .detach() : should not change the given data!
            errD_fake = LossFunc(output, label) # Binary CrossEntropy
            errD_fake.backward(retain_graph = True) # Gradients
            D_z = output.mean().item() # D(z) in float(to bring to CPU)
            ## E[D(x)] + E[1 - D(G(z))] ##
            errD = errD_real + errD_fake
            optimizerD.step() # the calculation on this is based on logarithmic calculations as it uses BCE loss.

            if i % 10 == 0:
                    print('[%d/%d][%d/%d]\tLoss_D: %.4f\ttalmo: %.4f\tnotalmo: %.4f'
                          % (epoch, num_epochs, i, len(talmodataloader),
                             errD.item(), D_x, D_z))

            D_Losses.append(errD.item())

    if saveData:
        save(netD, D_Losses)
    show_result(D_Losses)

def show_result(D_Losses = torch.load("DLoss.pt")):
    if D_Losses != []:
        plt.figure(figsize=(10,5))
        plt.title("Discriminator Loss During Training")
        plt.plot(D_Losses,label="D")
        plt.xlabel("iterations")
        plt.ylabel("Loss")
        plt.legend()
        plt.show()
    else:
        print("there is no saved loss data.")

def f():
    return discriminate("Testimg/Test")

def discriminate(root, index=0):
    data = dataset.ImageFolder(root = root, transform = transforms.Compose([
        transforms.Resize(64), # resizing into [64, 64<=] or [64<=, 64]
        transforms.CenterCrop(64), # having a square image of [64, 64]
        transforms.ToTensor(), # converting into tensor in order to use it
        transforms.Normalize((0.5, 0.5, 0.5),(0.5, 0.5, 0.5)) # 3D's mean & standard derivation = 0.5
        ]))
    dataloader = iter(udata.DataLoader(data, batch_size=1, num_workers=0))
    for i in range(index):
        next(dataloader)
    data = next(dataloader)[0].to(device)
    netD = Discriminator(0).to(device)
    netD.load_state_dict(torch.load("netD.pt"))
    
    y = netD(data.detach()).view(-1)[0]
    if y<0.9:
        y = math.log(y/(1-y))
        if y<0: y = -y
    else:
        y = math.exp(y)
        y = math.log(y)
        y = 100*y
    return y
