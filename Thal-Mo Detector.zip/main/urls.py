"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static


app_name = "main"

urlpatterns = [
    path("", views.nrt),
    path("Main_O/", views.Main_O),
    path("Main_X/", views.Main_X),
    path("<talmodata>,<title>", views.homepage),
    path('Main_O/upload/', views.ai),
    path('Main_X/nupload/', views.nai),
    path('Main_O/camera_ai/', views.camera_ai),
    path('Main_X/camera_ai/', views.camera_ai),
    path('Main_O/camera_opencv/', views.camera_opencv),
    path('Main_X/ncamera_opencv/', views.ncamera_opencv),
    path('opencv/', views.opencv),
    path('nopencv/', views.nopencv),
    path('Main_O/webcam_ai/', views.Home_ai),
    path('Main_X/webcam_ai/', views.Home_ai),
    path('Main_O/webcam_opencv/', views.Home_opencv),
    path('Main_X/webcam_opencv/', views.Home_opencv),
    path('result/', views.Result),
    path('cheers/', views.cheers),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)